import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:infractfinder/UploadScreen.dart';  // Import the UploadScreen
import 'package:infractfinder/PatientListScreen.dart';  // Import the UploadScreen

class PatientComplaintsScreen extends StatefulWidget {
  final String? username;

  PatientComplaintsScreen({this.username});

  @override
  _PatientComplaintsScreenState createState() => _PatientComplaintsScreenState();
}

class _PatientComplaintsScreenState extends State<PatientComplaintsScreen> {
  final TextEditingController patientIdController = TextEditingController();
  final TextEditingController nameController = TextEditingController();
  final TextEditingController ageController = TextEditingController();
  final TextEditingController genderController = TextEditingController();
  final List<String> medicalHistoryOptions = ["Diabetes", "Blood Pressure", "Comorbidities"];
  String? selectedMedicalHistory;
  final TextEditingController surgicalHistoryController = TextEditingController();
  final TextEditingController previousConditionsController = TextEditingController();
  final TextEditingController requestingPhysicianController = TextEditingController();
  final TextEditingController patientPositionController = TextEditingController();

  Future<void> submitData(BuildContext context) async {
    final Map<String, dynamic> data = {
      'patient_id': patientIdController.text.trim(),
      'name': nameController.text.trim(),
      'age': int.tryParse(ageController.text.trim()),
      'gender': genderController.text.trim(),
      'medical_history': selectedMedicalHistory ?? '',
      'surgical_history': surgicalHistoryController.text.trim(),
      'previous_conditions': previousConditionsController.text.trim(),
      'requesting_physician': requestingPhysicianController.text.trim(),
      'patient_position': patientPositionController.text.trim(),
    };

    if (data.containsValue('') || data.containsValue(null)) {
      _showErrorDialog(context, 'Please fill in all fields correctly.');
      return;
    }

    try {
      final response = await http.post(

        Uri.parse('http://14.139.187.229:8081/Infarctdetector/patient_details_and_complaints.php'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(data),
      );

      print("Response Status: ${response.statusCode}");
      print("Response Body: ${response.body}");

      if (response.statusCode == 200) {
        final responseData = json.decode(response.body);
        if (responseData['status'] == 'success') {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => UploadScreen()),
          );
        } else {
          _showErrorDialog(context, responseData['message']);
        }
      } else {
        _showErrorDialog(context, 'Failed to submit data. Please try again later.');
      }
    } catch (error) {
      print("Error: $error");
      _showErrorDialog(context, 'An error occurred. Please check your network connection.');
    }
  }

  void _showErrorDialog(BuildContext context, String message) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Error'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: Text('Okay'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          PopupMenuButton<String>(
            onSelected: (String value) {
              if (value == 'Patient List') {
                // Navigate to PatientListScreen when 'Patient List' is selected
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => PatientListScreen()),
                );
              }
            },
            itemBuilder: (BuildContext context) => <PopupMenuEntry<String>>[
              PopupMenuItem<String>(
                value: 'Patient List',
                child: Text('Patient List'),
              ),
            ],
            icon: Icon(Icons.more_vert, color: Colors.black),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Text(
                "Patient Details",
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  shadows: [
                    Shadow(
                      offset: Offset(2.0, 2.0),
                      blurRadius: 3.0,
                      color: Colors.grey.withOpacity(0.5),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(height: 24),
            _buildTextField(controller: patientIdController, label: 'Patient ID'),
            SizedBox(height: 16),
            _buildTextField(controller: nameController, label: 'Name'),
            SizedBox(height: 16),
            _buildTextField(controller: ageController, label: 'Age', keyboardType: TextInputType.number),
            SizedBox(height: 16),
            _buildTextField(controller: genderController, label: 'Gender'),
            SizedBox(height: 16),
            DropdownButtonFormField<String>(
              decoration: InputDecoration(labelText: "Medical History", border: OutlineInputBorder()),
              items: medicalHistoryOptions.map((String value) {
                return DropdownMenuItem<String>(value: value, child: Text(value));
              }).toList(),
              onChanged: (String? newValue) {
                setState(() {
                  selectedMedicalHistory = newValue;
                });
              },
            ),
            SizedBox(height: 16),
            _buildTextField(controller: surgicalHistoryController, label: 'Surgical History'),
            SizedBox(height: 16),
            _buildTextField(controller: previousConditionsController, label: 'Previous Conditions'),
            SizedBox(height: 16),
            _buildTextField(controller: requestingPhysicianController, label: 'Requesting Physician'),
            SizedBox(height: 16),
            _buildTextField(controller: patientPositionController, label: 'Patient Position'),
            SizedBox(height: 24),
            Center(
              child: ElevatedButton(
                onPressed: () => submitData(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color(0xFFFF5300),
                  shadowColor: Colors.black.withOpacity(0.5),
                  elevation: 8,
                ),
                child: Text(
                  "Next",
                  style: TextStyle(color: Colors.white, fontSize: 18),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    TextInputType keyboardType = TextInputType.text,
  }) {
    return TextField(
      controller: controller,
      decoration: InputDecoration(labelText: label, border: OutlineInputBorder()),
      keyboardType: keyboardType,
    );
  }
}
