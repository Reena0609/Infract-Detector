import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

import 'package:infractfinder/Csv.dart'; // Import the Welcome screen

class PatientListScreen extends StatefulWidget {
  @override
  _PatientListScreenState createState() => _PatientListScreenState();
}

class _PatientListScreenState extends State<PatientListScreen> {
  List _patients = [];
  List _filteredPatients = [];
  bool _isLoading = true;
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _fetchPatientList();
    _searchController.addListener(_filterPatients);
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _fetchPatientList() async {
    try {
      final response = await http.get(
        Uri.parse('http://192.168.138.72/sample/getpatients.php'),
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        setState(() {
          _patients = data.isNotEmpty ? data : [];
          _filteredPatients = _patients;
          _isLoading = false;
        });
      } else {
        throw Exception('Failed to load patients');
      }
    } catch (error) {
      setState(() {
        _isLoading = false;
      });
      print('Error fetching patients: $error');
    }
  }

  void _filterPatients() {
    final query = _searchController.text.toLowerCase();
    setState(() {
      _filteredPatients = _patients.where((patient) {
        final name = patient['name']?.toString()?.toLowerCase() ?? '';
        return name.contains(query);
      }).toList();
    });
  }

  void _showPatientDetails(Map<String, dynamic> patient) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(patient['name'] ?? 'N/A'),
          content: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Age: ${patient['age'] ?? 'N/A'}'),
                Text('Gender: ${patient['gender'] ?? 'N/A'}'),
                Text('Medical History: ${patient['medical_history'] ?? 'N/A'}'),
                Text('Surgical History: ${patient['surgical_history'] ?? 'N/A'}'),
                Text('Previous Conditions: ${patient['previous_conditions'] ?? 'N/A'}'),
                Text('Requesting Physician: ${patient['requesting_physician'] ?? 'N/A'}'),
                Text('Patient Position: ${patient['patient_position'] ?? 'N/A'}'),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Close'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Patient List'),
        actions: [
          IconButton(
            icon: const Icon(Icons.download),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => Welcome()),
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                labelText: 'Search',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8.0),
                ),
              ),
            ),
          ),
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _filteredPatients.isEmpty
                ? const Center(child: Text('No patients available'))
                : ListView.builder(
              itemCount: _filteredPatients.length,
              itemBuilder: (context, index) {
                final patient = _filteredPatients[index];
                return ListTile(
                  leading: const Icon(Icons.person),
                  title: Text(patient['name'] ?? 'Unknown'),
                  subtitle: Text(
                      'Age: ${patient['age'] ?? 'N/A'} | Gender: ${patient['gender'] ?? 'N/A'}'),
                  trailing: const Icon(Icons.arrow_forward_ios),
                  onTap: () => _showPatientDetails(patient),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
