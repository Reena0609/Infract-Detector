import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:infractfinder/SignupScreen.dart';
import 'dart:convert';

class SignupScreen extends StatefulWidget {
  @override
  _SignupScreenState createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController confirmPasswordController = TextEditingController();

  // Function to handle sign-up logic
  Future<void> handleSignup() async {
    final String username = usernameController.text;
    final String email = emailController.text;
    final String password = passwordController.text;
    final String confirmPassword = confirmPasswordController.text;

    // Validate input fields
    if (username.isEmpty || email.isEmpty || password.isEmpty || confirmPassword.isEmpty) {
      showAlert('Error', 'Please fill in all fields.');
      return;
    }

    // Check if passwords match
    if (password != confirmPassword) {
      showAlert('Error', 'Passwords do not match.');
      return;
    }

    // Backend logic: API endpoint URL
    const String signupApiUrl = 'http://14.139.187.229:8081/Infarctdetector/signup.php'; // Replace with your server URL

    // Make the POST request to the backend
    try {
      final response = await http.post(
        Uri.parse(signupApiUrl),
        headers: <String, String>{
          'Content-Type': 'application/json',
        },
        body: jsonEncode(<String, String>{
          'username': username,
          'email': email,
          'password': password,
          'confirmpassword': confirmPassword,
        }),
      );

      // Handle the response from the backend
      if (response.statusCode == 200) {
        final Map<String, dynamic> responseData = jsonDecode(response.body);

        if (responseData['success']) {
          showAlert('Success', responseData['message']);
        } else {
          showAlert('Error', responseData['message']);
        }
      } else {
        showAlert('Error', 'Failed to register. Please try again later.');
      }
    } catch (error) {
      showAlert('Error', 'An error occurred: $error');
    }
  }

  // Function to show alert dialogs
  void showAlert(String title, String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(title),
          content: Text(message),
          actions: <Widget>[
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final double windowHeight = MediaQuery.of(context).size.height;
    final double windowWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      backgroundColor: Colors.white,
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.only(top: windowHeight * 0.1),
          child: Column(
            children: [
              // Back button
              Align(
                alignment: Alignment.topLeft,
                child: IconButton(
                  icon: const Icon(Icons.arrow_back),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                ),
              ),
              // Title with user icon
              Padding(
                padding: EdgeInsets.only(top: windowHeight * 0.1),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      'Sign Up',
                      style: TextStyle(
                        fontSize: windowWidth * 0.08,
                        fontWeight: FontWeight.bold,
                        color: Colors.black,
                        shadows: [
                          Shadow(
                            color: Colors.black.withOpacity(0.5),
                            offset: const Offset(2, 2),
                            blurRadius: 5,
                          ),
                        ],
                      ),
                    ),
                    SizedBox(width: windowWidth * 0.02),
                    Icon(
                      Icons.person, // User icon
                      size: 50,
                      color: Colors.black,
                    ),
                  ],
                ),
              ),
              SizedBox(height: windowHeight * 0.05),
              // Input fields
              Padding(
                padding: EdgeInsets.symmetric(horizontal: windowWidth * 0.1),
                child: Column(
                  children: [
                    buildTextField('User Name', usernameController),
                    buildTextField('Enter Your Email', emailController),
                    buildTextField('Password', passwordController, isPassword: true),
                    buildTextField('Confirm Password', confirmPasswordController, isPassword: true),
                  ],
                ),
              ),
              SizedBox(height: windowHeight * 0.05),
              // Signup button
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFFF5300), // Updated button color to #FF5300
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15),
                  ),
                  elevation: 20,
                  minimumSize: Size(windowWidth * 0.3, windowHeight * 0.06),
                ),
                onPressed: handleSignup,
                child: Text(
                  'Sign Up',
                  style: TextStyle(color: Colors.white, fontSize: windowWidth * 0.04),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Helper function to create text fields
  Widget buildTextField(String hintText, TextEditingController controller, {bool isPassword = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: TextField(
        controller: controller,
        obscureText: isPassword,
        decoration: InputDecoration(
          hintText: hintText,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(20),
            borderSide: const BorderSide(color: Colors.orange),
          ),
          filled: true,
          fillColor: Colors.white.withOpacity(0.9),
        ),
      ),
    );
  }
}

void main() => runApp(MaterialApp(
  home: SignupScreen(),
));