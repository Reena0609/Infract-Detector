import 'package:flutter/material.dart';
import 'package:infractfinder/LoginScreen.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Title Text
            Text(
              'CT Infract Finder',
              style: TextStyle(
                fontSize: MediaQuery.of(context).size.width * 0.10,
                fontWeight: FontWeight.bold,
                color: Colors.grey[800],
                shadows: [
                  Shadow(
                    blurRadius: 4.0,
                    color: Colors.black.withOpacity(0.8),
                    offset: const Offset(2, 2),
                  ),
                ],
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(height: MediaQuery.of(context).size.height * 0.02),

            // Image with stroke
            Container(
              width: MediaQuery.of(context).size.width * 0.7,
              height: MediaQuery.of(context).size.width * 0.7,
              decoration: BoxDecoration(
                border: Border.all(
                  color: const Color(0xFFEE392E), // Stroke color
                  width: 4.0, // Stroke width
                ),
                borderRadius: BorderRadius.circular(8.0), // Rounded corners
                shape: BoxShape.rectangle,
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8.0), // Optional: make image corners rounded
                child: Image.asset(
                  'assets/logo.png', // Ensure the asset path is correct
                  fit: BoxFit.cover,
                ),
              ),
            ),

            SizedBox(height: MediaQuery.of(context).size.height * 0.07),
            ElevatedButton(
              onPressed: () {
                // Navigate to LoginScreen
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => LoginScreen()),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFFFF5300),
                minimumSize: Size(
                  MediaQuery.of(context).size.width * 0.5,
                  MediaQuery.of(context).size.height * 0.06,
                ),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(
                    MediaQuery.of(context).size.width * 0.04,
                  ),
                ),
                elevation: 5,
              ),
              child: Text(
                'Get Started',
                style: TextStyle(
                  fontSize: MediaQuery.of(context).size.width * 0.06,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
