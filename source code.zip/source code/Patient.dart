class Patient {
  final String patientId;
  final String name;
  final int age;
  final String gender;

  Patient({
    required this.patientId,
    required this.name,
    required this.age,
    required this.gender,
  });

  // Factory method to parse the JSON data
  factory Patient.fromJson(Map<String, dynamic> json) {
    return Patient(
      patientId: json['patient_id'],
      name: json['name'],
      age: json['age'],
      gender: json['gender'],
    );
  }
}
