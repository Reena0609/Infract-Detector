import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:infractfinder/UploadScreen.dart';

class CombinedPatientScreen extends StatefulWidget {
  @override
  _CombinedPatientScreenState createState() => _CombinedPatientScreenState();
}

class _CombinedPatientScreenState extends State<CombinedPatientScreen> {
  final TextEditingController patientIdController = TextEditingController();
  final TextEditingController nameController = TextEditingController();
  final TextEditingController ageController = TextEditingController();
  final TextEditingController genderController = TextEditingController();

  final List<String> medicalHistoryOptions = ["Diabetes", "Blood Pressure", "Comorbidities"];
  String? selectedMedicalHistory;
  TextEditingController surgicalHistoryController = TextEditingController();
  TextEditingController previousConditionsController = TextEditingController();
  TextEditingController requestingPhysicianController = TextEditingController();
  TextEditingController patientPositionController = TextEditingController();

  // Function to submit form data to backend
  Future<void> submitData() async {
    final Map<String, dynamic> patientData = {
      'patient_id': patientIdController.text.trim(),
      'name': nameController.text.trim(),
      'age': int.tryParse(ageController.text.trim()),
      'gender': genderController.text.trim(),
      'medical_history': selectedMedicalHistory ?? '',
      'surgical_history': surgicalHistoryController.text,
      'previous_conditions': previousConditionsController.text,
      'requesting_physician': requestingPhysicianController.text,
      'patient_position': patientPositionController.text,
    };

    if (patientData['patient_id'] == '' ||
        patientData['name'] == '' ||
        patientData['age'] == null ||
        patientData['gender'] == '' ||
        patientData['medical_history'] == '' ||
        patientData['surgical_history'] == '' ||
        patientData['previous_conditions'] == '' ||
        patientData['requesting_physician'] == '' ||
        patientData['patient_position'] == '') {
      _showErrorDialog("Please fill in all fields correctly.");
      return;
    }

    try {
      final response = await http.post(
        Uri.parse('http://14.139.187.229:8081/Infarctdetector/patientdetailsandcomplaints.php'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(patientData),
      );

      if (response.statusCode == 200) {
        final responseData = json.decode(response.body);
        if (responseData['status'] == 'success') {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => UploadScreen()),
          );
        } else {
          _showErrorDialog(responseData['message']);
        }
      } else {
        _showErrorDialog("Failed to submit data. Please try again later.");
      }
    } catch (error) {
      _showErrorDialog("An error occurred. Please check your network connection.");
    }
  }

  void _showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text("Error"),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: Text("OK"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text(
              "Patient Details & Complaints",
              style: TextStyle(fontSize: 25, fontWeight: FontWeight.w600),
            ),
            SizedBox(height: 24),
            _buildTextField(controller: patientIdController, label: "Patient ID"),
            SizedBox(height: 16),
            _buildTextField(controller: nameController, label: "Name"),
            SizedBox(height: 16),
            _buildTextField(controller: ageController, label: "Age", keyboardType: TextInputType.number),
            SizedBox(height: 16),
            _buildTextField(controller: genderController, label: "Gender"),
            SizedBox(height: 24),
            DropdownButtonFormField<String>(
              decoration: InputDecoration(
                labelText: "Medical History",
                border: OutlineInputBorder(),
              ),
              items: medicalHistoryOptions.map((String value) {
                return DropdownMenuItem<String>(value: value, child: Text(value));
              }).toList(),
              onChanged: (String? newValue) {
                setState(() {
                  selectedMedicalHistory = newValue;
                });
              },
            ),
            SizedBox(height: 16),
            _buildTextField(controller: surgicalHistoryController, label: "Surgical History"),
            SizedBox(height: 16),
            _buildTextField(controller: previousConditionsController, label: "Previous Conditions"),
            SizedBox(height: 16),
            _buildTextField(controller: requestingPhysicianController, label: "Requesting Physician"),
            SizedBox(height: 16),
            _buildTextField(controller: patientPositionController, label: "Patient Position"),
            SizedBox(height: 30),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: Color(0xFFFF5300),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20),
                ),
              ),
              onPressed: submitData,
              child: Text("Submit", style: TextStyle(color: Colors.white, fontSize: 18)),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    TextInputType keyboardType = TextInputType.text,
  }) {
    return TextField(
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(),
      ),
      keyboardType: keyboardType,
    );
  }
}
