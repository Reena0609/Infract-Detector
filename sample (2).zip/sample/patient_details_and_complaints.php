<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");

$input = json_decode(file_get_contents('php://input'), true);

if (isset($input['patient_id'], $input['name'], $input['age'], $input['gender'], $input['medical_history'], $input['surgical_history'], $input['previous_conditions'], $input['requesting_physician'], $input['patient_position'])) {
    
    $patientId = $input['patient_id'];
    $name = $input['name'];
    $age = $input['age'];
    $gender = $input['gender'];
    $medicalHistory = $input['medical_history'];
    $surgicalHistory = $input['surgical_history'];
    $previousConditions = $input['previous_conditions'];
    $requestingPhysician = $input['requesting_physician'];
    $patientPosition = $input['patient_position'];

    $host = "localhost"; 
    $dbname = "medical";
    $username = "root";
    $password = "";

    // Enable error reporting for debugging
    error_reporting(E_ALL);
    ini_set('display_errors', 1);

    // Create a connection
    $conn = new mysqli($host, $username, $password, $dbname);

    // Check the connection
    if ($conn->connect_error) {
        echo json_encode(["status" => "error", "message" => "Database connection failed: " . $conn->connect_error]);
        exit();
    }

    $query = "INSERT INTO patient_details (patient_id, name, age, gender, medical_history, surgical_history, previous_conditions, requesting_physician, patient_position)
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssissssss", $patientId, $name, $age, $gender, $medicalHistory, $surgicalHistory, $previousConditions, $requestingPhysician, $patientPosition);

    if ($stmt->execute()) {
        echo json_encode(["status" => "success", "message" => "Data saved successfully."]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to save data: " . $stmt->error]);
    }

    $stmt->close();
    $conn->close();
} else {
    echo json_encode(["status" => "error", "message" => "Invalid input."]);
}
?>
